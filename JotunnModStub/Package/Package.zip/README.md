﻿# Windlass
Another OP weapon by Zarboz



## Installation (manual)

Click Go on the install things

## Features
Fully configurable damage for a cool bow

## Changelog
V0.1.1 - First Public Release

V0.1.2 - Fixed equipped SE and made it fully configurable for server owners  (local admins)

## Known issues
You can find the github at:
