﻿# Windlass
Another OP weapon by Zarboz



## Installation (manual)

Click Go on the install things

## Features
Fully configurable damage for a cool bow

## Changelog
V0.1.1 - First Public Release

## Known issues
You can find the github at:
